// generated from rosidl_generator_c/resource/idl.h.em
// with input from buggy:srv/CustomSrv.idl
// generated code does not contain a copyright notice

#ifndef BUGGY__SRV__CUSTOM_SRV_H_
#define BUGGY__SRV__CUSTOM_SRV_H_

#include "buggy/srv/detail/custom_srv__struct.h"
#include "buggy/srv/detail/custom_srv__functions.h"
#include "buggy/srv/detail/custom_srv__type_support.h"

#endif  // BUGGY__SRV__CUSTOM_SRV_H_
