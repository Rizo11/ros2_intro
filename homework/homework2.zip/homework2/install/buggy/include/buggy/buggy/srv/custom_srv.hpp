// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef BUGGY__SRV__CUSTOM_SRV_HPP_
#define BUGGY__SRV__CUSTOM_SRV_HPP_

#include "buggy/srv/detail/custom_srv__struct.hpp"
#include "buggy/srv/detail/custom_srv__builder.hpp"
#include "buggy/srv/detail/custom_srv__traits.hpp"

#endif  // BUGGY__SRV__CUSTOM_SRV_HPP_
