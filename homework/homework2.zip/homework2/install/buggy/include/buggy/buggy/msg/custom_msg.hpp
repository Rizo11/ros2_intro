// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef BUGGY__MSG__CUSTOM_MSG_HPP_
#define BUGGY__MSG__CUSTOM_MSG_HPP_

#include "buggy/msg/detail/custom_msg__struct.hpp"
#include "buggy/msg/detail/custom_msg__builder.hpp"
#include "buggy/msg/detail/custom_msg__traits.hpp"

#endif  // BUGGY__MSG__CUSTOM_MSG_HPP_
