// generated from rosidl_generator_c/resource/idl.h.em
// with input from buggy:msg/CustomMsg.idl
// generated code does not contain a copyright notice

#ifndef BUGGY__MSG__CUSTOM_MSG_H_
#define BUGGY__MSG__CUSTOM_MSG_H_

#include "buggy/msg/detail/custom_msg__struct.h"
#include "buggy/msg/detail/custom_msg__functions.h"
#include "buggy/msg/detail/custom_msg__type_support.h"

#endif  // BUGGY__MSG__CUSTOM_MSG_H_
