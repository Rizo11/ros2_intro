from buggy.msg._custom_msg import CustomMsg  # noqa: F401
